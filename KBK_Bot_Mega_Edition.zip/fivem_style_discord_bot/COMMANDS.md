# Command Inventory

## Moderation
`/ban` `/unban` `/kick` `/timeout` `/untimeout` `/warn` `/warnings` `/clear-warnings` `/purge` `/slowmode` `/lock` `/unlock` `/lockdown` `/unlockdown`

## Administration
`/userinfo` `/serverinfo` `/nick` `/role` `/say` `/embed` `/config` `/setlogs` `/setwelcome`

## Community
`/suggest` `/ticket` `/poll`

## Staff
`/staff promote` `/staff demote` `/staff list`

## Custom
`/custom set` `/custom test`

## Security
Anti-Raid, Anti-Spam, Anti-Mass-Actions, Anti-Bot, AutoMod toggle, Lockdown.
