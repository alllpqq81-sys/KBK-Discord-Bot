# KBK Discord Bot — Mega Edition

بوت ديسكورد مخصص لسيرفر KBK، مع إدارة وحماية ومجتمع واقتصاد وتذاكر وXP وGiveaways وتقديم إدارة.

## الميزات
- 🛡️ Anti-Raid / Anti-Spam / Anti-Nuke / AutoMod من النظام الأساسي
- 👮 Ban / Kick / Timeout / Warn / Lockdown / إدارة الرتب
- 🎫 Tickets + Claim + Close + Transcript-ready structure
- 📋 Staff Applications
- 💰 Coins + Daily + Work + Pay + Leaderboards
- ⭐ XP + Levels + Profiles + Achievements
- 💡 Suggestions + Polls
- 🎉 Giveaways
- 📊 Server Stats + Logs + Welcome
- ⚙️ إعدادات الحماية واللوق والترحيب والتذاكر والاقتراحات

## Replit
1. ارفع المشروع.
2. ضع `DISCORD_TOKEN` و `CLIENT_ID` في Secrets.
3. شغّل `npm install`.
4. شغّل `npm run build`.
5. شغّل `npm run register` لتسجيل أوامر Slash.
6. شغّل `npm start`.

فعّل Message Content Intent وServer Members Intent من Discord Developer Portal إذا كانت ميزات الرسائل/الحماية تحتاجها.
