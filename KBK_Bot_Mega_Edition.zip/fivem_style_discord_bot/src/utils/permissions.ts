import { ChatInputCommandInteraction, PermissionFlagsBits } from "discord.js";

export function requirePermission(i: ChatInputCommandInteraction, permission: bigint) {
  if (!i.memberPermissions?.has(permission)) {
    i.reply({ content: "❌ لا تملك الصلاحية المطلوبة.", ephemeral: true });
    return false;
  }
  return true;
}

export function isOwner(i: ChatInputCommandInteraction) {
  const owner = process.env.OWNER_ID;
  return Boolean(owner && i.user.id === owner);
}
