import {
  AuditLogEvent, Client, Guild, GuildMember, PermissionsBitField
} from "discord.js";
import { Database } from "./Database.js";
import { logAction } from "./Logger.js";

type Counter = { count: number; started: number };
const joins = new Map<string, Counter>();
const actions = new Map<string, Counter>();
const messages = new Map<string, { count: number; started: number }>();

export class Protection {
  constructor(private client: Client, private db: Database) {}

  async onMemberJoin(member: GuildMember) {
    const c = this.db.config(member.guild.id);
    if (c.antiBot && member.user.bot) {
      await member.kick("Anti-Bot").catch(() => {});
      return;
    }
    if (!c.antiRaid) return;
    const key = member.guild.id;
    const now = Date.now();
    const x = joins.get(key) ?? { count: 0, started: now };
    if (now - x.started > 20_000) {
      x.count = 0; x.started = now;
    }
    x.count++;
    joins.set(key, x);
    if (x.count >= 8) {
      await lockdown(member.guild, this.db);
      await logAction(this.client, this.db, key, "🚨 Anti-Raid", "تم تفعيل Lockdown بسبب دخول عدد كبير من الأعضاء خلال فترة قصيرة.", 0xed4245);
    }
  }

  async onMessage(message: any) {
    if (!message.guild || message.author?.bot) return;
    const c = this.db.config(message.guild.id);
    if (!c.antiSpam) return;
    const key = `${message.guild.id}:${message.author.id}`;
    const now = Date.now();
    const x = messages.get(key) ?? { count: 0, started: now };
    if (now - x.started > 7_000) { x.count = 0; x.started = now; }
    x.count++;
    messages.set(key, x);
    if (x.count >= 7) {
      x.count = 0;
      await message.member?.timeout(30_000, "Anti-Spam").catch(() => {});
      await message.channel.send(`⚠️ ${message.author} تم تقييدك مؤقتًا بسبب Spam.`).catch(() => {});
    }
  }

  async onGuildAudit(guild: Guild, executorId: string | undefined, type: AuditLogEvent) {
    const c = this.db.config(guild.id);
    if (!c.antiMassActions || !executorId) return;
    if (executorId === this.client.user?.id) return;
    const key = `${guild.id}:${executorId}:${type}`;
    const now = Date.now();
    const x = actions.get(key) ?? { count: 0, started: now };
    if (now - x.started > 15_000) { x.count = 0; x.started = now; }
    x.count++;
    actions.set(key, x);
    if (x.count >= 5) {
      const member = await guild.members.fetch(executorId).catch(() => null);
      if (member?.manageable) {
        await member.timeout(10 * 60_000, "Anti-Mass-Actions").catch(() => {});
        await logAction(this.client, this.db, guild.id, "🛡️ Anti-Nuke", `تم تقييد الإداري <@${executorId}> بعد رصد عمليات جماعية.`, 0xed4245);
      }
      x.count = 0;
    }
  }
}

export async function lockdown(guild: Guild, db: Database) {
  db.updateConfig(guild.id, { lockdown: true });
  for (const channel of guild.channels.cache.values()) {
    if (!channel.isTextBased() || !("permissionOverwrites" in channel)) continue;
    await channel.permissionOverwrites.edit(guild.roles.everyone, {
      SendMessages: false
    }).catch(() => {});
  }
}

export async function unlock(guild: Guild, db: Database) {
  db.updateConfig(guild.id, { lockdown: false });
  for (const channel of guild.channels.cache.values()) {
    if (!channel.isTextBased() || !("permissionOverwrites" in channel)) continue;
    await channel.permissionOverwrites.edit(guild.roles.everyone, {
      SendMessages: null
    }).catch(() => {});
  }
}
