import { Client, EmbedBuilder, TextChannel } from "discord.js";
import { Database } from "./Database.js";

export async function logAction(
  client: Client,
  db: Database,
  guildId: string,
  title: string,
  description: string,
  color = 0x5865f2
) {
  const config = db.config(guildId);
  if (!config.logChannelId) return;
  const channel = await client.channels.fetch(config.logChannelId).catch(() => null);
  if (!channel || !(channel instanceof TextChannel)) return;
  await channel.send({
    embeds: [
      new EmbedBuilder()
        .setColor(color)
        .setTitle(title)
        .setDescription(description)
        .setTimestamp()
    ]
  }).catch(() => {});
}
