import fs from "node:fs";
import path from "node:path";
import { DatabaseShape, GuildConfig, UserRecord, WarnRecord, StaffRecord, TicketRecord, GiveawayRecord, ApplicationRecord } from "../types/models.js";
const dir=path.resolve("data"), file=path.join(dir,"database.json");
const defaults:DatabaseShape={configs:[],warns:[],staff:[],users:[],tickets:[],giveaways:[],applications:[],customCommands:{}};
export class Database{
 private data:DatabaseShape=structuredClone(defaults);
 constructor(){fs.mkdirSync(dir,{recursive:true});if(fs.existsSync(file)){try{this.data={...structuredClone(defaults),...JSON.parse(fs.readFileSync(file,"utf8"))};}catch{this.data=structuredClone(defaults);}}}
 private save(){fs.writeFileSync(file,JSON.stringify(this.data,null,2),"utf8")}
 config(guildId:string){let c=this.data.configs.find(x=>x.guildId===guildId);if(!c){c={guildId,antiRaid:true,antiSpam:true,antiMassActions:true,antiWebhook:true,antiBot:false,lockdown:false,automod:true,xpPerMessage:5,bannedWords:[]};this.data.configs.push(c);this.save()}return c}
 updateConfig(guildId:string,patch:Partial<GuildConfig>){Object.assign(this.config(guildId),patch);this.save();return this.config(guildId)}
 addWarn(r:WarnRecord){this.data.warns.push(r);this.save()}; warns(g:string,u:string){return this.data.warns.filter(x=>x.guildId===g&&x.userId===u)}; clearWarns(g:string,u:string){this.data.warns=this.data.warns.filter(x=>!(x.guildId===g&&x.userId===u));this.save()}
 staff(g:string){return this.data.staff.filter(x=>x.guildId===g)}; setStaff(r:StaffRecord){const old=this.data.staff.find(x=>x.guildId===r.guildId&&x.userId===r.userId);if(old)Object.assign(old,r);else this.data.staff.push(r);this.save()}; removeStaff(g:string,u:string){this.data.staff=this.data.staff.filter(x=>!(x.guildId===g&&x.userId===u));this.save()}
 user(g:string,u:string){let x=this.data.users.find(v=>v.guildId===g&&v.userId===u);if(!x){x={guildId:g,userId:u,coins:0,xp:0,level:1,rep:0,messages:0,voiceMinutes:0,achievements:[]};this.data.users.push(x);this.save()}return x}
 updateUser(g:string,u:string,patch:Partial<UserRecord>){Object.assign(this.user(g,u),patch);this.save();return this.user(g,u)}
 topUsers(g:string,field:"coins"|"xp"|"rep"|"messages"){return this.data.users.filter(x=>x.guildId===g).sort((a,b)=>b[field]-a[field]).slice(0,10)}
 addTicket(r:TicketRecord){this.data.tickets.push(r);this.save()}; ticket(channelId:string){return this.data.tickets.find(x=>x.channelId===channelId)}; removeTicket(channelId:string){this.data.tickets=this.data.tickets.filter(x=>x.channelId!==channelId);this.save()}; tickets(g:string){return this.data.tickets.filter(x=>x.guildId===g)}
 addGiveaway(r:GiveawayRecord){this.data.giveaways.push(r);this.save()}; giveaway(messageId:string){return this.data.giveaways.find(x=>x.messageId===messageId)}; updateGiveaway(id:string,p:Partial<GiveawayRecord>){const x=this.giveaway(id);if(x)Object.assign(x,p);this.save()}; activeGiveaways(){return this.data.giveaways.filter(x=>!x.ended)}
 addApplication(r:ApplicationRecord){this.data.applications.push(r);this.save()}; applications(g:string){return this.data.applications.filter(x=>x.guildId===g)}; updateApplication(g:string,u:string,status:ApplicationRecord["status"]){const x=this.data.applications.find(a=>a.guildId===g&&a.userId===u&&a.status==="pending");if(x)x.status=status;this.save()}
 setCustomCommand(g:string,n:string,r:string){this.data.customCommands[`${g}:${n.toLowerCase()}`]=r;this.save()}; getCustomCommand(g:string,n:string){return this.data.customCommands[`${g}:${n.toLowerCase()}`]}
}
