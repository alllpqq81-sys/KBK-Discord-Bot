import { Client, Events, Interaction, GuildMember, TextChannel, ButtonInteraction, ModalSubmitInteraction, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } from "discord.js";
import { Database } from "../services/Database.js";
import { Protection } from "../services/Protection.js";
import { execute } from "../commands/index.js";
import { logAction } from "../services/Logger.js";

export function registerEvents(client:Client,db:Database){
 const protection=new Protection(client,db);
 client.once(Events.ClientReady,c=>{console.log(`✅ Logged in as ${c.user.tag}`);console.log(`📡 Serving ${c.guilds.cache.size} guild(s)`);startGiveawayWatcher(client,db)});
 client.on(Events.InteractionCreate,async(i:Interaction)=>{try{if(i.isChatInputCommand())await execute(i,db);else if(i.isButton())await handleButton(i,db);else if(i.isModalSubmit())await handleModal(i,db)}catch(e){console.error(e);if(i.isRepliable()&&!i.replied&&!i.deferred)await i.reply({content:"❌ حدث خطأ أثناء تنفيذ العملية.",ephemeral:true}).catch(()=>{})}});
 client.on(Events.GuildMemberAdd,async m=>{await protection.onMemberJoin(m);const c=db.config(m.guild.id);if(c.welcomeChannelId){const ch=await m.guild.channels.fetch(c.welcomeChannelId).catch(()=>null);if(ch instanceof TextChannel)await ch.send((c.welcomeMessage??"أهلًا {user} في {server}!").replaceAll("{user}",m.toString()).replaceAll("{server}",m.guild.name)).catch(()=>{})}});
 client.on(Events.MessageCreate,async m=>{await protection.onMessage(m);if(m.author.bot||!m.guild)return;const c=db.config(m.guild.id);if(c.automod&&c.bannedWords?.some(w=>m.content.toLowerCase().includes(w.toLowerCase()))){await m.delete().catch(()=>{});await logAction(client,db,m.guild.id,"🛡️ AutoMod",`تم حذف رسالة من ${m.author} بسبب كلمة ممنوعة.`,0xed4245);return}const u=db.user(m.guild.id,m.author.id);u.messages++;const gain=c.xpPerMessage??5;u.xp+=gain;const newLevel=Math.floor(u.xp/100)+1;if(newLevel>u.level){u.level=newLevel;await m.channel.send(`🎉 ${m.author} وصل إلى المستوى **${newLevel}**!`).catch(()=>{})}db.updateUser(m.guild.id,m.author.id,u)});
 client.on(Events.GuildAuditLogEntryCreate,async(entry,guild)=>{await protection.onGuildAudit(guild,entry.executorId??undefined,entry.action)});
}

async function handleButton(i:ButtonInteraction,db:Database){
 if(i.customId==="ticket_open"){
  const g=i.guild!,c=db.config(g.id),existing=db.tickets(g.id).find(t=>t.userId===i.user.id);
  if(existing)return i.reply({content:`لديك تذكرة مفتوحة بالفعل: <#${existing.channelId}>`,ephemeral:true});
  const ch=await g.channels.create({name:`ticket-${i.user.username}`.toLowerCase().replace(/[^a-z0-9-]/g,"").slice(0,70)||"ticket",type:0,parent:c.ticketCategoryId,permissionOverwrites:[{id:g.roles.everyone.id,deny:["ViewChannel"]},{id:i.user.id,allow:["ViewChannel","SendMessages","ReadMessageHistory"]},...(c.ticketSupportRoleId?[{id:c.ticketSupportRoleId,allow:["ViewChannel","SendMessages","ReadMessageHistory"]}]:[])]});
  db.addTicket({guildId:g.id,channelId:ch.id,userId:i.user.id,openedAt:Date.now()});
  await ch.send({content:`🎫 ${i.user} أهلاً بك في تذكرتك.`,components:[new ActionRowBuilder<ButtonBuilder>().addComponents(new ButtonBuilder().setCustomId("ticket_claim").setLabel("استلام").setStyle(ButtonStyle.Primary),new ButtonBuilder().setCustomId("ticket_close").setLabel("إغلاق").setStyle(ButtonStyle.Danger))]});
  return i.reply({content:`تم فتح التذكرة: ${ch}`,ephemeral:true});
 }
 if(i.customId==="ticket_close"){const t=db.ticket(i.channelId);if(!t)return i.reply({content:"هذه ليست تذكرة مسجلة.",ephemeral:true});await i.reply("🔒 سيتم إغلاق التذكرة...");db.removeTicket(i.channelId);setTimeout(()=>i.channel?.delete().catch(()=>{}),1200);return}
 if(i.customId==="ticket_claim"){const t=db.ticket(i.channelId);if(!t)return i.reply({content:"التذكرة غير مسجلة.",ephemeral:true});db.updateConfig(i.guild!.id,{});await i.reply(`👮 تم استلام التذكرة بواسطة ${i.user}.`);await logAction(i.client,db,i.guild!.id,"🎫 Ticket Claim",`${i.user} استلم <#${i.channelId}>`);return}
 if(i.customId.startsWith("app_accept:")||i.customId.startsWith("app_reject:")){
  if(!i.memberPermissions?.has("ManageGuild"))return i.reply({content:"❌ لا تملك الصلاحية.",ephemeral:true});
  const uid=i.customId.split(":")[1]; const status=i.customId.startsWith("app_accept:")?"accepted":"rejected" as any;
  db.updateApplication(i.guild!.id,uid,status); return i.update({content:`${status==="accepted"?"✅ تم قبول الطلب":"❌ تم رفض الطلب"} — <@${uid}>`,components:[]});
 }
 if(i.customId==="suggest_up"||i.customId==="suggest_down"){await i.deferUpdate();const emoji=i.customId==="suggest_up"?"👍":"👎";await i.message.react(emoji).catch(()=>{});return}
}

async function handleModal(i:ModalSubmitInteraction,db:Database){
  if(i.customId!=="staff_apply") return;
  const g=i.guild!;
  db.addApplication({guildId:g.id,userId:i.user.id,answers:[i.fields.getTextInputValue("age"),i.fields.getTextInputValue("experience"),i.fields.getTextInputValue("why")],status:"pending",createdAt:Date.now()});
  const c=db.config(g.id);
  if(c.applicationChannelId){
    const ch=await g.channels.fetch(c.applicationChannelId).catch(()=>null);
    if(ch?.isTextBased()){
      await ch.send({
        embeds:[new EmbedBuilder().setColor(0x5865f2).setTitle("📋 طلب إدارة جديد").setDescription(`المتقدم: ${i.user}\nالعمر: ${i.fields.getTextInputValue("age")}\nالخبرة: ${i.fields.getTextInputValue("experience")}\nالسبب: ${i.fields.getTextInputValue("why")}`)],
        components:[new ActionRowBuilder<ButtonBuilder>().addComponents(
          new ButtonBuilder().setCustomId(`app_accept:${i.user.id}`).setLabel("قبول").setStyle(ButtonStyle.Success),
          new ButtonBuilder().setCustomId(`app_reject:${i.user.id}`).setLabel("رفض").setStyle(ButtonStyle.Danger)
        )]
      });
    }
  }
  return i.reply({content:"✅ تم إرسال طلبك للإدارة.",ephemeral:true});
}

function startGiveawayWatcher(client:Client,db:Database){setInterval(async()=>{for(const g of db.activeGiveaways()){if(Date.now()<g.endsAt)continue;const ch=await client.channels.fetch(g.channelId).catch(()=>null);if(!ch?.isTextBased())continue;const msg=await ch.messages.fetch(g.messageId).catch(()=>null);const entries=g.entries.length?g.entries:msg?.reactions.cache.get("🎉")?Array.from((await msg.reactions.cache.get("🎉")!.users.fetch()).values()).filter(u=>!u.bot).map(u=>u.id):[];const winners=[...entries].sort(()=>Math.random()-0.5).slice(0,g.winners);if(msg)await msg.edit({embeds:[new EmbedBuilder().setColor(0x57f287).setTitle("🎉 انتهى السحب").setDescription(`**الجائزة:** ${g.prize}\n**الفائزون:** ${winners.length?winners.map(x=>`<@${x}>`).join(", "):"لا يوجد فائزين"}`)]}).catch(()=>{});if(ch)await ch.send(`🎉 انتهى السحب! ${winners.length?`الفائزون: ${winners.map(x=>`<@${x}>`).join(", ")}`:"لم يوجد مشاركون."}`).catch(()=>{});db.updateGiveaway(g.messageId,{ended:true})}},15000)}
