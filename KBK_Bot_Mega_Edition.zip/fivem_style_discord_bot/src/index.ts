import "dotenv/config";
import { Client, GatewayIntentBits, Partials } from "discord.js";
import { Database } from "./services/Database.js";
import { registerEvents } from "./events/index.js";

const token = process.env.DISCORD_TOKEN;
if (!token) throw new Error("DISCORD_TOKEN is missing in .env");

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildModeration,
    GatewayIntentBits.GuildMessageReactions
  ],
  partials: [Partials.Channel, Partials.Message, Partials.GuildMember]
});

const db = new Database();
registerEvents(client, db);

process.on("unhandledRejection", console.error);
process.on("uncaughtException", console.error);

client.login(token);
