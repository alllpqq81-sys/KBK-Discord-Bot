export type WarnRecord = { userId:string; guildId:string; moderatorId:string; reason:string; createdAt:number };
export type StaffRecord = { userId:string; guildId:string; level:number; title:string; updatedAt:number; attendance?:number; points?:number };
export type UserRecord = { userId:string; guildId:string; coins:number; xp:number; level:number; rep:number; lastDaily?:number; lastWork?:number; messages:number; voiceMinutes:number; achievements:string[] };
export type TicketRecord = { guildId:string; channelId:string; userId:string; claimedBy?:string; openedAt:number };
export type GiveawayRecord = { guildId:string; channelId:string; messageId:string; prize:string; endsAt:number; winners:number; entries:string[]; ended?:boolean };
export type ApplicationRecord = { guildId:string; userId:string; answers:string[]; status:"pending"|"accepted"|"rejected"; createdAt:number };
export type GuildConfig = {
  guildId:string; logChannelId?:string; welcomeChannelId?:string; welcomeMessage?:string;
  ticketCategoryId?:string; ticketSupportRoleId?:string; suggestionChannelId?:string; staffRoleId?:string;
  antiRaid:boolean; antiSpam:boolean; antiMassActions:boolean; antiWebhook:boolean; antiBot:boolean; lockdown:boolean; automod:boolean;
  bannedWords?:string[]; xpPerMessage?:number; levelRewardRoleIds?:Record<string,string>; applicationChannelId?:string;
};
export type DatabaseShape = { configs:GuildConfig[]; warns:WarnRecord[]; staff:StaffRecord[]; users:UserRecord[]; tickets:TicketRecord[]; giveaways:GiveawayRecord[]; applications:ApplicationRecord[]; customCommands:Record<string,string>; };
